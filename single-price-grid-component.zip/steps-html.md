# HTML
[x] Criar o arquivo index.html
[] Abrir o index no navegador e já abrir a ferramenta de responsividade, deixando no tamanho mobile M (375px)
[] Exibir o ícone do Favicon
[] Criar o <main> dentro do <body>
[] Criar duas <div>, uma para a parte de cima e outra para a parte de baixo do card

## <div> superior
[] Criar uma <section> que conterá um <h1> e dois <p>. Essa section conterá todas as informações da parte de cima do card

## <div> inferior
[] Criar duas <section>, uma para as informações do lado esquerdo e outra para as informações do lado direito

### <section> esquerda
[] Criar um <h2>, uma <div> com dois <p> dentro e FORA dessa <div> outro <p> e um <button>

### <section> direita
[] Criar um <h2> e 7 <p>