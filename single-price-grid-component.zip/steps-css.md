**Todas as medidas devem ser rem
# CSS
[] Fazer o reset do CSS3
[] Criar um :root com as cores do projeto
[] Diminuir o tamanho do HTML para 62.5%
[] Mudar a cor do fundo do <body> para Grayish Blue
[] Colocar um preenchimento no <body> de 32px (em rem)
[] Adicionar a variável --bright-cyan: #4ABFBD ao seu :root. Essa é a cor da <section> inferior direita
[] Mudar a cor de fundo de cada umas das <section> para a sua cor respectiva


## Estilização dos Textos
[] Importar os tamanhos 400 e 700 da fonte Karla e aplicar do * do CSS3.

### <section> da <div> superior
[] Mudar o tamanho do <h1> para 20px (em rem) e sua cor para Cyan
[] Alterar o tamanho da fonte do primeiro <p> para 15px (em rem) e a cor de sua fonte para Bright Yellow
[] Mudar o tamanho do segundo <p> para 14px (em rem) e a cor de sua fonte para Grayish Blue
[] Colocar um espaço entre linhas nos dois <p> de 20px (em rem)

### <section> esquerda da <div> inferior 
[] Mudar o tamanho do <h2> para 18px (em rem) e sua cor para branco
[] Mudar a fonte do PRIMEIRO <p> dentro da <div> para 32px (em rem), sua cor para branco e a intensidade da sua fonte para 700
[] Alterar a cor do SEGUNDO <p> dentro da <div> para 16px (em rem), sua cor para branco e sua opacidade para 0.5
[] Mudar a fonte do <p> que está FORA da <div> para 16px (em rem) e sua cor para branco
[] Mudar o tamanho da fonte do <button> para 16px (em rem) e sua cor para branco
[] Mudar a cor de fundo do <button> para Bright Yellow

### <section> direita da <div> inferior 
[] Mudar a fonte do <h2> para 18px (em rem) e sua cor de fonte para branco
[] Mudar a fonte dos <p> para 14px (em rem), sua cor de fonte para branco e sua opacidade para 0.75
[] Colocar um espaço entre linhas de 20px (em rem)


## Posicionamentos, margens e preenchimentos
[] Mudar o preenchimento de todas as <section> para 24px (em rem)

### <section> da <div> superior
[] Colocar uma distância entre o <h1> e o primeiro <p> de 24px (em rem)
[] Colocar uma distância entre o primeiro <p> e o segundo <p> de 16px (em rem)
[] Arredondar os dois cantos superiores em 8px (em rem)

### <section> esquerda da <div> inferior
[] Colocar uma distância entre o <h2> e a <div> de 18px (em rem)
[] Posicionar os dois <p> que estão dentro da <div> um ao lado do outro e alinhados ao centro na vertical
[] Adicionar uma distância entre os dois <p> que estão dentro da <div> de 12px (em rem)
[] Fazer o <button> ocupar todo o espaço disponível na horizontal
[] Adicionar um preenchimento de 15px (em rem) ao <button>
[] Arredondar os quatro cantos do <button> em 5px (em rem)
[] Retirar a borda do <button>
[] Adicionar uma distância entre a <div> e o <p> de 4px (em rem)
[] Adicionar uma distância entre o <p> e o <button> de 26px (em rem)

### <section> direita da <div> inferior
[] Adicionar uma distância de 18px (em rem) entre o <h2> e o primeiro <p>
[] Arredondar os dois cantos inferiores em 8px (em rem)